#!/bin/bash
#部署基于域名的网站
yum -y install gcc pcre-devel openssl-devel
if [ $? -eq 0 ];then
   tar -xf /root/lnmp_soft.tar.gz
   tar -xf /root/lnmp_soft/nginx-1.12.2.tar.gz -C /root/
   cd /root/nginx-1.12.2
   ./configure --with-http_ssl_module --with-stream --with-http_stub_status_module
   make && make install 
else
   exit
fi
#部署基于端口的网站
cd /usr/local/nginx/
#基于端口号80安全web
mkdir  bbb && echo "恭喜您成功创建端口80的www.b.com网站" >   bbb/index.html
#基于端口号80动态web，www.c.com
mkdir  b8b 
#基于端口号8080
mkdir  aaa  && echo "恭喜您成功创建端口8080的www.a.com:8080网站" >  aaa/index.html

#部署动态网站
cd /root/lnmp_soft/
yum -y install php php-mysql  php-fpm-5.4.16-42.el7.x86_64.rpm
yum -y install mariadb mariadb-server mariadb-devel
systemctl start  php-fpm
systemctl enable php-fpm
systemctl start  mariadb
systemctl enable mariadb
tar -xf /root/lnmp_soft/php_scripts/php-memcached-demo.tar.gz -C /root/
cd  /root/php-memcached-demo
cp -r  * /usr/local/nginx/b8b/

#部属安全的web网站
cd /usr/local/nginx/conf/
#生成私钥
openssl genrsa > cert.key
#生成公钥
rpm -q  expect
[ $? -eq 0 ] || yum -y install expect
sleep  10
#取本机的ip地址
b=`ifconfig eth0 | awk '/inet /{print $2}'`
expect << EOF
spawn ssh -o StrictHostKeyChecking=no  root@$b
expect "password:" {send "123456\r"}
expect "#" {send "cd /usr/local/nginx/conf/\r"}
expect "#" {send "openssl req -new -x509 -key cert.key > cert.pem\r"}
expect ":" {send "xk\r"}
expect ":" {send "xk\r"}
expect ":" {send "xk\r"}
expect ":" {send "xk\r"}
expect ":"  {send "xk\r"}
expect ":"   {send "xk\r"}
expect ":"  {send "xiangkui@163.com\r"}
expect "#" {send "exit\r"}
EOF

rm -rf /usr/local/nginx/conf/nginx.conf 
cp /root/nginx.conf  /usr/local/nginx/conf/nginx.conf
if [ $? -eq 0 ];then
ln -s /usr/local/nginx/sbin/nginx  /usr/bin/
nginx
nginx -s reload
else
   exit
fi
echo "$b www.a.com www.b.com www.c.com" >> /etc/hosts
