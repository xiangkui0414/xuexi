#!/bin/bash
#$1是虚拟机号(注：01～100)
#$2是网段
#$3是主机号
#$4是主机名
a=$1
b=$2
c=$3
add="nmcli connection add type ethernet con-name eth1 ifname eth1"
nmcli="nmcli connection modify eth0 ipv4.method manual ipv4.address '192.168.$b.$c/24' connection.autoconnect yes"
nmcli1="nmcli connection modify eth1 ipv4.method manual ipv4.address '192.168.$b.$c/24' connection.autoconnect yes"
host=$4
[ -d /xk/yum.repos.d ] || mkdir -p /xk/yum.repos.d/ 
echo "[rhel7]
name=xiangkui
baseurl=ftp://192.168.$b.254/rhel7
enabeld=1
gpgcheck=0" > /xk/yum.repos.d/dvd.repo
expect <<  EOF
spawn clone-vm7
expect "number:" {send "$a\r"}
expect "#"          { send "exit\r" }
EOF
virsh start "rh7_node$a"
sleep 2
if [ $b -eq 2 ];then
   expect << EOF
   spawn virsh console "rh7_node$a"
   expect "login:" {send "root\r"}
   expect "login:" {send "root\r"}
   expect "密码："  {send "123456\r"}
   expect "#" {send "hostnamectl set-hostname $host\r"}
   expect "#"  {send "$add\r"}
   expect "#"   {send "$nmcli1\r"}
   expect "#" {send "nmcli connection up eth1\r"}
   expect "#"  {send "exit\r"}
EOF
else 
   expect << EOF
   spawn virsh console "rh7_node$a"
   expect "login:" {send "root\r"}
   expect "login:" {send "root\r"}
   expect "密码："  {send "123456\r"}
   expect "#" {send "hostnamectl set-hostname $host\r"}
   expect "#"   {send "$nmcli\r"}
   expect "#" {send "nmcli connection up eth0\r"}
   expect "#"  {send "exit\r"}
EOF
fi

sleep 15
#给新建虚拟机传输yum源
expect << EOF
spawn scp "/xk/yum.repos.d/dvd.repo" "root@192.168.$b.$c:/etc/yum.repos.d/"
expect "(yes/no)?" {send "yes\r"}
expect "password:" {send "123456\r"}
expect "#"  {send "exit\r"}
EOF
#传输公钥方便后期的免密远程
#注：为了防止别的机器不能免密运程，请先查看一下本地是否已经生成了密钥
#若本地没有密钥请先创建密钥
#ssh-keygen -f /root/.ssh/id_rsa -N ''
expect << EOF
spawn  ssh-copy-id 192.168.$b.$c
expect "(yes/no)?" {send "yes\r"}
expect "password:" {send "123456\r"}
expect "#"  {send "exit\r"}
EOF
#把部署nginx的包传输过去
scp "/root/nginx.sh" "root@192.168.$b.$c:/root/"
scp "/root/lnmp_soft.tar.gz" "root@192.168.$b.$c:/root/"
scp "/root/nginx.conf"  "root@192.168.$b.$c:/root/"
#一键部署nginx的脚本请看/root/nginx.sh
expect << EOF
spawn ssh root@192.168.$b.$c
expect "#" {send "chmod +x /root/nginx.sh\r"}
expect "#" {send "exit\r"}
EOF
